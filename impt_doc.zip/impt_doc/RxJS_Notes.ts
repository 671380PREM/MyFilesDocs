map, mapTo - import { take, mapTo, map  } from 'rxjs/operators';
of,            - import { Observable,Observer,Subscription, timer, concat, interval, fromEvent, of  } from 'rxjs';

You can use pipes to link operators together. 
Pipes lets you combine multiple functions into a single function. 
The pipe() function takes as its arguments the functions you want to combine, 
and returns a new function that, when executed, runs the composed functions in sequence.


A promise is a TypeScript object which is used to write asynchronous programs. 
A promise is always a better choice when it comes to managing multiple asynchronous operations, 
error handling and better code readability.

var promise = new Promise(function(resolve, reject) {
    setTimeout(function() {
      reject('I promise to return this after 5 second!');
    }, 5000);
  });
  promise.then(function(value) {
    console.log(value);
  });

  timer(),
  interval(),
  pipe(),
  of(),
  forkJoin(),
  concat(),
  mapTo().
  map()
  


