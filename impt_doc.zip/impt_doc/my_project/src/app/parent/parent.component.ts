import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { ChildComponent } from "../child/child.component";
import { AppService } from "../app.service";
import { UserList } from "../user-list";
import { Observable } from 'rxjs';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.scss']
})
export class ParentComponent implements OnInit, AfterViewInit  {
  @ViewChild(ChildComponent, {static: false}) child: ChildComponent;

  ngAfterViewInit() {
    console.log(this.child.whoAmi());
  }
  title:string = 'Parent';
  myInputMessage:string ="I am the parent component";
  objData:any;
  userList: UserList[];
  observable: any;

  public CData: number;
  constructor(private appService: AppService) { }

  ngOnInit() {
    this.observable =  this.appService.getUsers();
    console.log(this.observable);
    // this.getUserData();
    this.objData = {
      firstName: "Prashant",
      lastName: "Prem"
    }
  }

  GetChildData(data){  
    console.log(data);  
 }  

//  getUserData(){
//    this.appService.getUsers().subscribe((res: UserList[])=>{
//       console.log(res);
//       this.userList = res;
//    },(err)=>{
//       console.log(err);
//    })
//  }

}