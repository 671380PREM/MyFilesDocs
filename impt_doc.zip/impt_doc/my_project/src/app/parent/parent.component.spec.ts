import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
import { ParentComponent } from './parent.component';
import { ChildComponent } from '../child/child.component';
import { HttpClientModule } from '@angular/common/http';
import { StatusPipe } from "../status.pipe";

describe('ParentComponent', () => {
  let component: ParentComponent;
  let fixture: ComponentFixture<ParentComponent>;
  let de: DebugElement;

  beforeEach(() => {
    let component: ParentComponent;
  });

  afterEach(() => {
    let component: ParentComponent;
  });

  it('should return if we get the data', () => {
    expect(component.observable).toBeTruthy();
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientModule
      ],
      declarations: [ ParentComponent, ChildComponent, StatusPipe ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
  it(`should have as title 'Parent'`, () => {
    const fixture = TestBed.createComponent(ParentComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app.title).toEqual('Parent');
  });

  it('should have a h3 tag of `Parent Component`', () => {
    const de = fixture.debugElement;
    expect(de.query(By.css('h3')).nativeElement.innerText).toBe('Parent Component');
});

});
