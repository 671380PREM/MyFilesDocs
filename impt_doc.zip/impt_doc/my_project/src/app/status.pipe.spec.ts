import { StatusPipe } from './status.pipe';

describe('StatusPipe', () => {
  // let status: StatusPipe;
  const status: StatusPipe = new StatusPipe();
  it('create an instance', () => {
    const pipe = new StatusPipe();
    expect(pipe).toBeTruthy();
  });
  it('providing false returns Incomplete', () => {
    expect(status.transform(false, false)).toBe('Incomplete');
  });

  it('providing true value returns Completed', () => {
    expect(status.transform(true, true)).toBe('Completed');
  });
});
