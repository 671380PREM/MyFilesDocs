import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ThreeComponent } from "./three/three.component";
import { FourComponent } from "./four/four.component";
import { ParentComponent } from "./parent/parent.component";

const routes: Routes = [
  { path: "three", component: ThreeComponent },
  { path: "four", component: FourComponent },
  { path: "parent", component: ParentComponent},
  { path: "", redirectTo: "/parent", pathMatch: "full" },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
