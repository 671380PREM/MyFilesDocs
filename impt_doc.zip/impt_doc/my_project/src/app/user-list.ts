export interface UserList {
    userId: number,
    id: number,
    title: string,
    completed: boolean
}
