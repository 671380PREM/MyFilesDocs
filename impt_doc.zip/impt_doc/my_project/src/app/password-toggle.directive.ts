import { Directive } from '@angular/core';

@Directive({
  selector: '[appPasswordToggle]'
})
export class PasswordToggleDirective {

  toggle: string = "password";
  toggleIcon: string = "fa fa-eye-slash"

  constructor() { 
    
   }

   togglePassword() {

    if(this.toggle == "text") {
      this.toggle = "password";
      this.toggleIcon = "fa fa-eye-slash";
    } else {
      this.toggle = "text";
      this.toggleIcon = "fa fa-eye";
    }
  }

}
