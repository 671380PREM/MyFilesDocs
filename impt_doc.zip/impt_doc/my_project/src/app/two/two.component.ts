import { Component, OnInit } from '@angular/core';
import { SharedServiceService} from '../shared-service.service';

@Component({
  selector: 'app-two',
  templateUrl: './two.component.html',
  styleUrls: ['./two.component.scss']
})
export class TwoComponent implements OnInit {

  message:any;

  constructor(private sharedService: SharedServiceService) { }

  ngOnInit() {
    this.sharedService.sharedMessage.subscribe(message => this.message = message);
  }

  newMessage(myCustomMsg) {
    this.sharedService.nextMessage(myCustomMsg);
  }

}
