import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.scss']
})
export class ChildComponent implements OnInit {

  @Input() PData: number;

  @Input() myinputMsg: string; 

  @Output() childEvent = new EventEmitter();

  @Output() myOutput: EventEmitter<string> = new EventEmitter();  

  outputMessage:string="I am child component.";
  objDataChild: any;

  constructor() { }
  onChange(value) {
    this.childEvent.emit(value);
  }

  ngOnInit() {
    console.log(this.myinputMsg); 
    this.objDataChild = {
      firstName: "Child",
      lastName: "Data"
    }
  }

  whoAmi() {
    return "I am chid baba!!!";
  }

  sendValues(){  
    this.myOutput.emit(this.objDataChild);  
 }

}