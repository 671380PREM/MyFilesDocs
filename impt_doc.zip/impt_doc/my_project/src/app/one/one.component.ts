import { Component, OnInit, HostListener } from '@angular/core';
import { SharedServiceService} from '../shared-service.service';

@Component({
  selector: 'app-one',
  templateUrl: './one.component.html',
  styleUrls: ['./one.component.scss']
})
export class OneComponent implements OnInit {

  message:any;

  constructor(private sharedService: SharedServiceService) { }

  ngOnInit() {
    this.sharedService.sharedMessage.subscribe(message => this.message = message)
  }

  // @HostListener('window:beforeunload', ['$event'])
  //     unloadNotification($event: any) {
  //       sessionStorage.setItem("myData", this.message);
  //     }

}
