import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'status'
})
export class StatusPipe implements PipeTransform {

  transform(value: any, completed: boolean): any {
    console.log(completed);
    if(completed === false) {
      return "Incomplete"
    } else {
      return "Completed";
    }
    
  }

}
