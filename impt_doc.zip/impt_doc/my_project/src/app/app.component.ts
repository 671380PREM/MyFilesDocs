import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable, Observer, Subscription, timer, concat, interval, fromEvent, of, forkJoin } from 'rxjs';
import { take, mapTo, map, filter } from 'rxjs/operators';
import {
  HttpClient
} from "@angular/common/http";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'myProject';

  customSubscrition: Subscription;
  http: any;
  loadedCharacter: any;
  posts = [
    {
      id: 1,
      title: 'Angular Http Post Request Example'
    },
    {
      id: 2,
      title: 'Angular 8 Routing and Nested Routing Tutorial With Example'
    },
    {
      id: 3,
      title: 'How to Create Custom Validators in Angular 8?'
    },
    {
      id: 4,
      title: 'How to Create New Component in Angular 8?'
    }
  ];
  constructor(private httpClient: HttpClient) { }

  ngOnInit() {
    console.log(this.add("Hello ", "Steve")); // returns "Hello Steve" 
    console.log(this.add(10, 20)); // returns 30
    const getPostOne = [timer(1000).pipe(mapTo({ id: 1, iD: 3 }))];
    const getPostTwo = [timer(5000).pipe(mapTo({ id: 2, iD: 4 }))];
    console.log("---" + getPostOne);
    console.log(getPostTwo);
    forkJoin(getPostOne, getPostTwo).subscribe(res => console.log(res));

    const observable = forkJoin([
      of(1, 2, 3, 4),
      Promise.resolve(8),
      timer(4000),
    ]);
    observable.subscribe({
      next: value => console.log(value),
      complete: () => console.log('This is how it ends!'),
    });


    let sampleOf = of(1, 2, 3).pipe(
      map(x => x + 1),
      filter(x => x > 2)
    );
    sampleOf.subscribe(
      x => console.log('next:', x),
      err => console.log('error:', err),
      () => console.log('the end'),
    );


    const clicks = fromEvent(document, 'click');
    const positions = clicks.pipe(map(ev => ev));
    positions.subscribe(x => console.log(x));

    const clickss = fromEvent(document, 'click');
    const greetings = clickss.pipe(mapTo('Hi'));
    greetings.subscribe(x => console.log(x));


    // const greetings = interval(1000).pipe(mapTo('Hi'));
    // greetings.subscribe(x => console.log(x));

    const timer1 = interval(500).pipe(take(2));
    const timer2 = interval(1000).pipe(take(3));
    const timer3 = interval(2000).pipe(take(4));

    const result = concat(timer1, timer2, timer3);
    result.subscribe(x => console.log(x));

    const numbers = timer(3000);
    numbers.subscribe(x => console.log('---------' + x));
    // Creating Observable.
    // Create method takes function as a argument with Observer.

    const myObservables = Observable.create((observer: Observer<string>) => {

      // Emit the first data package after 2 seconds.
      // next pushes the next data package.
      // Emitting string data types
      setTimeout(() => {
        observer.next('FIRST RESPONSE****:')
      }, 2000);

      // Emit the second data package after 4 seconds.
      // next pushes the next data package.
      // Emitting string data types

      setTimeout(() => {
        observer.next('SECOND RESPONSE****:')
      }, 4000);

      // Emit the error package after 5 seconds.
      // error emits the error response.
      // Emitting string data types

      setTimeout(() => {
        observer.error('ERROR RESPONSE****:')
      }, 5000)

      // Emits the complete.
      setTimeout(() => {
        observer.complete();
      }, 6000)

    });


    // Subsribe the observable
    // first callbacks take success.
    // second callbacks takes failure
    // third call backs takes completion.
    this.customSubscrition = myObservables.subscribe((response: string) => {
      console.log("RESPONSE: ", response);
    },
      (error: string) => {
        console.log("FAILURE RESPONSE: ", error);
      },
      () => {
        // This will not be called since there is an error at 5 seconds before the completion.
        console.log("COMPLETION:");
      }
    );
  }

  ngOnDestroy() {
    // unsubscribes the subscription.
    this.customSubscrition.unsubscribe();
  }

  add(a: string, b: string): string;

  add(c: number, d: number): number;

  add(e: any, f: any): any {
    return e + f;
  }



}

class Greeter {
  greeting: string;
  public customMsz: string = "Custom message";
  constructor(message: string) {
      this.greeting = message;
  }
  greet() {
      return "Hello, " + this.greeting;
  }
}
let greeter = new Greeter("world");
console.log(greeter.greet());
console.log(greeter.customMsz);

// class Animal {
//   protected name: string;
//   constructor(name: string) { this.name = name; }
//   move(distanceInMeters: number = 0) {
//       console.log(`Animal moved ${distanceInMeters}m.`);
//   }
// }
// class Dog extends Animal {
//   constructor(name: string, department: string) {
//     super(name);

// }
//   bark() {
//       console.log('Woof! Woof!');
//   }
// }
// const dog = new Dog("Howard", "Sales");
// dog.bark();
// dog.move(1002);
// dog.bark();

// class Person {
//   protected name: string;
//   constructor(name: string) { this.name = name; }
// }

// class Employee extends Person {
//   private department: string;

//   constructor(name: string, department: string) {
//       super(name);
//       this.department = department;
//   }

//   public getElevatorPitch() {
//       return `Hello, my name is ${this.name} and I work in ${this.department}.`;
//   }
// }

// let howard = new Employee("Howard", "Sales");
// console.log(howard.getElevatorPitch());
// console.log(howard.name); // error

// abstract class Department {

//   constructor(public name: string) {
//   }

//   printName(): void {
//       console.log("Department name: " + this.name);
//   }

//   abstract printMeeting(): void; // must be implemented in derived classes
// }

// class AccountingDepartment extends Department {

//   constructor() {
//       super("Accounting and Auditing"); // constructors in derived classes must call super()
//   }

//   printMeeting(): void {
//       console.log("The Accounting Department meets each Monday at 10am.");
//   }

//   generateReports(): void {
//       console.log("Generating accounting reports...");
//   }
// }

// let department: Department; // ok to create a reference to an abstract type
// department = new Department(); // error: cannot create an instance of an abstract class
// department = new AccountingDepartment(); // ok to create and assign a non-abstract subclass
// department.printName();
// department.printMeeting();
// department.generateReports(); // error: method doesn't exist on declared abstract type
