import { Component, OnInit } from '@angular/core';
import { SharedServiceService} from '../shared-service.service';

@Component({
  selector: 'app-four',
  templateUrl: './four.component.html',
  styleUrls: ['./four.component.scss']
})
export class FourComponent implements OnInit {

  message:any;

  constructor(private sharedService: SharedServiceService) { }

  ngOnInit() {
    this.sharedService.sharedMessage.subscribe(message => this.message = message);
  }

}
