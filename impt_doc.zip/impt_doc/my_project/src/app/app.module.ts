import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { NgxPasswordToggleModule } from 'ngx-password-toggle';
import { PasswordToggleDirective } from './password-toggle.directive';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { OneComponent } from './one/one.component';
import { TwoComponent } from './two/two.component';
import { ThreeComponent } from './three/three.component';
import { FourComponent } from './four/four.component'; 
import { FormsModule } from '@angular/forms';
import { InterceptorService } from './interceptor.service';
import { StatusPipe } from './status.pipe';
import { PostComponent } from './post/post.component';

@NgModule({
  declarations: [
    AppComponent,
    ParentComponent,
    ChildComponent,
    PasswordToggleDirective,
    OneComponent,
    TwoComponent,
    ThreeComponent,
    FourComponent,
    StatusPipe,
    PostComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgxPasswordToggleModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: InterceptorService,
    multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
