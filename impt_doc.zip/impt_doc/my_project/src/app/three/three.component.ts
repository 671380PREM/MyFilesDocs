import { Component, OnInit } from '@angular/core';
import { SharedServiceService} from '../shared-service.service';

@Component({
  selector: 'app-three',
  templateUrl: './three.component.html',
  styleUrls: ['./three.component.scss']
})
export class ThreeComponent implements OnInit {

  message:any;

  constructor(private sharedService: SharedServiceService) { }

  ngOnInit() {
    this.sharedService.sharedMessage.subscribe(message => {
      this.message = message;
    });
  }

}
